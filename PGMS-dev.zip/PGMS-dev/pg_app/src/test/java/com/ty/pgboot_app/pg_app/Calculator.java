package com.ty.pgboot_app.pg_app;

public class Calculator {
	
	//sum
	public int doSum(int a, int b, int c) {
		return a+b+c;
	}
	
	//product
	public int doProduct(int a, int b) {
		return a*b;
	}
	
	//compare
	public boolean compareTwoNums(int a, int b) {
		return a == b;
	}
}
