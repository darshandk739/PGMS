package com.ty.pgboot_app.pg_app.dto;

public enum Role {
	MANAGER,
	ADMIN,
	PGOWNER
}
